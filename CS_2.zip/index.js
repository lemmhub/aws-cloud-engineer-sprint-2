var express = require("express");
var bodyParser = require("body-parser");
var mysql = require("mysql");
var app = express();
var bd;

const iniciarConexion = () => {
  bd = mysql.createConnection({
    host: "database-2.cluster-cbijw1bqknrk.us-east-1.rds.amazonaws.com",
    user: "admin", // Sustituir por tu usuario
    password: "holamundo", // Sustituir por tu clave
    database: "pizzas", // Esta base de datos debe estar creada en tu ambiente local
    port: 3306,
  });

  bd.on("error", function (err) {
    console.log("Error al conectar con la base de datos");
    if (err.sqlMessage) {
      if (err.sqlMessage.includes("Unknown database")) {
        console.log("La base de datos [ autos ] no ha sido encontrada");
        return;
      }
      if (
        err.sqlMessage.includes("Access denied for user") ||
        err.sqlMessage.includes("Client does not support authentication")
      ) {
        console.log(
          "Usuario y/o clave incorrectos. Sugerencia: utilizar [ root ] y [ root12345 ]"
        );
        return;
      }
      console.log(err.sqlMessage);
    } else {
      console.log(err);
    }
  });

  bd.connect();
  console.log("Aplicación corriendo en el puerto 8080");
};

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static("./"));

app.get("/", (req, res) => res.sendFile(__dirname + "/index.html"));
app.get("/administrar", (req, res) => res.sendFile(__dirname + "/crud.html"));

app.get("/pizzas", (req, res) => {
  if (!bd) {
    res
      .status(500)
      .send(
        "No se ha podido consultar la base de datos. Revisar logs del servidor"
      );
    return;
  }
  bd.query("SELECT * FROM catalogo", (error, results) => {
    if (error) {
      if (error.code === "ER_NO_SUCH_TABLE") {
        const err =
          "No se ha encontrado la tabla [ catalogo ] debe correr el script basededatos.sql";
        console.log(err);
      }
      res
        .status(500)
        .send("Error al consultar la base de datos, revisar logs del servidor");
    } else {
      res.setHeader("Content-Type", "application/json");
      res.send(results);
    }
  });
});

app.post("/pizzas", (req, res) => {
  if (!bd) {
    res
      .status(500)
      .send(
        "No se ha podido consultar la base de datos. Revisar logs del servidor"
      );
    return;
  }
  const { id, descripcion,ingredientes, precio, imagen } = req.body;
  let sql = `INSERT INTO catalogo(descripcion, precio, ingredientes, imagen) VALUES('${descripcion}','${precio}','${ingredientes}','${imagen}')`;
  if (id) {
    sql = `UPDATE catalogo set descripcion = '${descripcion}', precio = '${precio}', ingredientes='${ingredientes}',imagen = '${imagen}' where id = ${id}`;
  }

  bd.query(sql, (error, results) => {
    if (error) {
      console.log(error);
      res
        .status(500)
        .send(
          "Error al guardar en la base de datos, revisar logs del servidor"
        );
    } else {
      res.setHeader("Content-Type", "application/json");
      res.send(results);
    }
  });
});

app.delete("/pizzas/:id", (req, res) => {
  if (!bd) {
    res
      .status(500)
      .send(
        "No se ha podido consultar la base de datos. Revisar logs del servidor"
      );
    return;
  }

  const sql = `DELETE FROM catalogo WHERE id = '${req.params.id}'`;

  bd.query(sql, (error, results) => {
    if (error) {
      console.log(error);
      res
        .status(500)
        .send(
          "Error al eliminar en la base de datos, revisar logs del servidor"
        );
    } else {
      res.setHeader("Content-Type", "application/json");
      res.send(results);
    }
  });
});

app.listen(8080, () => {
  iniciarConexion();
});

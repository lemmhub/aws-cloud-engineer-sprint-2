CREATE TABLE `pizzas`.`catalogo` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `descripcion` VARCHAR(100) NULL,
  `ingredientes` VARCHAR(100) NULL,
  `precio` FLOAT NULL,
  `imagen` VARCHAR(1000) NULL,
  PRIMARY KEY (`id`));

  INSERT INTO `pizzas`.`catalogo` (`descripcion`, `precio`, `ingredientes`,`imagen`) VALUES ('Hongos', '200', 'Zetas, Cheddar, Jitomate, Carnes Frías','https://ce-cloudsprint-2.s3.amazonaws.com/images/hongos.png');
  INSERT INTO `pizzas`.`catalogo` (`descripcion`, `precio`,`ingredientes`, `imagen`) VALUES ('Mexicana', '250', 'Chorizo, Cheddar, Aguacate', 'https://ce-cloudsprint-2.s3.amazonaws.com/images/mexicana.png');
  INSERT INTO `pizzas`.`catalogo` (`descripcion`, `precio`, `ingredientes`,`imagen`) VALUES ('Pepperoni', '250', 'Pepperoni, Cheddar, Jitomate','https://ce-cloudsprint-2.s3.amazonaws.com/images/pepperoni.png');
  INSERT INTO `pizzas`.`catalogo` (`descripcion`, `precio`,`ingredientes`, `imagen`) VALUES ('Salami', '200','Salami, Cheddar, Jitomate', 'https://ce-cloudsprint-2.s3.amazonaws.com/images/salami.png');
  INSERT INTO `pizzas`.`catalogo` (`descripcion`, `precio`, `ingredientes`,`imagen`) VALUES ('Suprema', '280','Pepperoni, Salami, Zetas, Cheddar, Jitomate', 'https://ce-cloudsprint-2.s3.amazonaws.com/images/suprema.png');
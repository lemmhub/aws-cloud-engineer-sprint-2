const e = React.createElement;
let contexto;
class Crud extends React.Component {
  constructor(props) {
    super(props);
    this.state = { pizzas: [], session: false, pizza: {} };
    contexto = this;
  }

  manejarCambio = (evento) => {
    const { id, value } = evento.target;
    contexto.setState({ pizza: { ...contexto.state.pizza, [id]: value } });
  };

  guardar = (evento) => {
    evento.preventDefault();
    axios
      .post("/pizzas", contexto.state.pizza)
      .then(function () {
        contexto.obtenerPizzas();
        alert("Guardado correctamente");
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  limpiar = () => {
    contexto.setState({ pizza: {} });
  };

  seleccionar = (pizza) => () => {
    contexto.setState({ pizza });
  };

  eliminar = (pizza) => (evento) => {
    evento.preventDefault();
    axios
      .delete(`/pizzas/${pizza.id}`)
      .then(function () {
        contexto.obtenerPizzas();
        alert("Eliminado correctamente");
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  obtenerPizzas = () => {
    axios
      .get("/pizzas")
      .then(function (response) {
        contexto.setState({ pizzas: response.data });
      })
      .catch(function (error) {
        console.log(error);
      });
  };

  componentDidMount() {
    this.setState({ session: localStorage.sesion });
    this.obtenerPizzas();
  }

  render() {
    const { pizzas, pizza } = this.state;
    return (
      <div>
        <div class="card crud-form">
          <form>
            <div class="form-group">
              <div class="form-group">
                <label for="exampleInputPassword1">Nombre</label>
                <input
                  type="text"
                  class="form-control"
                  id="descripcion"
                  value={pizza.descripcion}
                  onChange={this.manejarCambio}
                />
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1">Ingredientes</label>
                <input
                  type="text"
                  class="form-control"
                  id="ingredientes"
                  value={pizza.ingredientes}
                  onChange={this.manejarCambio}
                />
                </div>
              <div class="form-group">
                <label for="exampleInputPassword1">Precio</label>
                <input
                  type="number"
                  class="form-control"
                  id="precio"
                  value={pizza.precio}
                  onChange={this.manejarCambio}
                />
              </div>
              <label for="exampleInputEmail1">Imagen</label>
              <input
                type="text"
                class="form-control"
                aria-describedby="imagen"
                id="imagen"
                value={pizza.imagen}
                onChange={this.manejarCambio}
              />
              <small id="emailHelp" class="form-text text-muted">
                El valor debe ser una URL
              </small>
            </div>

            <button
              type="submit"
              class="btn btn-secondary limpiar-btn"
              onClick={this.limpiar}
            >
              Limpiar
            </button>

            <button
              type="submit"
              class="btn btn-primary"
              onClick={this.guardar}
            >
              Guardar
            </button>
          </form>
        </div>
        <div class="card">
          <table class="table table">
            <thead>
              <tr>
                <th scope="col">Pizza</th>
                <th scope="col">Ingredientes</th>
                <th scope="col">Precio</th>
                <th scope="col">Imagen</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              {pizzas.map((c) => (
                <tr key={c.descripcion}>
                  <th scope="row">{c.descripcion}</th>
                  <td>{c.ingredientes}</td>
                  <td>{c.precio}</td>
                  <td>
                    <div style={{ maxWidth: 500 }}>{c.imagen}</div>
                  </td>
                  <td>
                    <button
                      type="button"
                      class="btn btn-danger"
                      onClick={this.eliminar(c)}
                    >
                      Eliminar
                    </button>
                    &nbsp;
                    <button
                      type="button"
                      class="btn btn-secondary"
                      onClick={this.seleccionar(c)}
                    >
                      Editar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const contenedor = document.querySelector("#crud");
ReactDOM.render(e(Crud), contenedor);

const e = React.createElement;

class Catalogo extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = { pizzas: [] };
  }

  componentDidMount() {
    const component = this;
    axios
      .get("/pizzas")
      .then(function (response) {
        component.setState({ pizzas: response.data });
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  render() {
    const { pizzas } = this.state;
    return (
      <div className="row">
        {pizzas.map((a) => (
          <div className="col-12 col-md-6 col-lg-4" key={a.id}>
            <div className="card shadow-sm tarjeta">
              <img
                src={a.imagen}
                className="card-img-top"
                alt={`pizza${a.id}`}
              />
              <div className="card-body">
                <h5 className="card-title">{a.descripcion}</h5>
                <p className="card-text">
                Ingredientes  {a.ingredientes}
                <br></br>
                Precio <b>$ {a.precio}</b>
                </p>
                <a href="#" className="btn btn-success">
                  Comprar
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
}

const contenedor = document.querySelector("#mi-aplicacion-react");
ReactDOM.render(e(Catalogo), contenedor);
